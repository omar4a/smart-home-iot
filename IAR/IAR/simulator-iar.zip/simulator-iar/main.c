#include "tm4c.h"
#include "project.h"
#include <stdbool.h>


int main(void) {
  ////////temp///////
   float temperature; 
    uint32_t adc_value; 
 
    ADC0_Init();    // Initialize ADC0 
    Buzzer_Init();  // Initialize Buzzer 
    UART0_Init();   // Initialize UART0 
 
    while (1) { 
        adc_value = ADC0_Read();                // Read ADC value 
        temperature = ConvertToTemperature(adc_value); // Convert to temperature 
         
        // Send temperature to the desktop application via UART 
        char buffer[50]; 
        sprintf(buffer, "%.2f", temperature); // Send only the temperature value 
        UART0_WriteString(buffer); 
        UART0_WriteChar('\n'); // End with a newline character for easier parsing 
 
        if (temperature > TEMPERATURE_THRESHOLD) { 
            Buzzer_On();  // Turn buzzer on 
        } else { 
            Buzzer_Off(); // Turn buzzer off 
        } 
 
        for (volatile int i = 0; i < 2000000; i++); // Simple delay 
    } 
    /////////////////////////
    
    

    
}

